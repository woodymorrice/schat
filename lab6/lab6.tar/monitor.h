/* CMPT332 - Group 14
 * Phong Thanh Nguyen (David) - wdz468 - 11310824
 * Woody Morrice - wam553 - 11071060 */

int RttMonInit(int numConds);
int RttMonEnter();
int RttMonLeave();
int RttMonWait(int CV);
int RttMonSignal(int CV);
int RttMonServer();

