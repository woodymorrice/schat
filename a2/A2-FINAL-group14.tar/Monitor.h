/* CMPT332 - Group 14
 * Phong Thanh Nguyen (David) - wdz468 - 11310824
 * Woody Morrice - wam553 - 11071060 */

int MonInit(int numConds);
int MonEnter();
int MonLeave();
int MonWait(int CV);
int MonSignal(int CV);

